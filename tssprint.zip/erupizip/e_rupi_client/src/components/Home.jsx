import React from 'react'

function Home() {
    return (
        <div className="main">
            <div className="section">
                
            </div>
        </div>
    )
}

export default Home
