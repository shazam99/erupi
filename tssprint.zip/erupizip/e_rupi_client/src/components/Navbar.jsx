import React from 'react'

function Navbar() {
  return (
    <nav>
      <h6 className='mx-4 pt-2 pb-2'>E Rupi</h6>
    </nav>
  )
}

export default Navbar
